/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
 import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a number (1-5): ");
        int num = sc.nextInt();
        int replacedNumber = -1; // Initialize to -1 to handle invalid input

        switch (num) {
            case 1:
                replacedNumber = 100;
                break;
            case 2:
                replacedNumber = 200;
                break;
            case 3:
                replacedNumber = 300;
                break;
            case 4:
                replacedNumber = 400;
                break;
            case 5:
                replacedNumber = 500;
                break;
            default:
                replacedNumber = -1; // Invalid input
        }

        if (replacedNumber != -1) {
            System.out.println("The number " + num + " is replaced by: " + replacedNumber);
        } else {
            System.out.println("Invalid input! Please enter a number between 1 and 5.");
        }

        sc.close();
    }
}
